import logo from "../assets/images/oxiom-logo-150x150.png";

const Logo = () => {
  return (
    <img width={100} height={100} src={logo} alt="jobify" className="logo" />
  );
};

export default Logo;
