import React from "react";

const InputContainer = () => {
  return (
    <div className="input-container">
      <input type="text" name="" id="" />
      <button>SEND</button>
    </div>
  );
};

export default InputContainer;
