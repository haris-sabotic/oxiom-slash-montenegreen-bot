import React, { useState, useEffect } from "react";
import Logo from "./Logo";
import FormRow from "./FormRow";
import Alert from "./Alert";
import Wrapper from "../assets/wrappers/RegisterPage";

const initialState = {
  name: "",
  email: "",
  password: "",
  isMember: true,
  question: "",
  answer: "",
};

const Form = () => {
  const [data, setData] = useState("");
  const [showAlert, setShowAlert] = useState(false);
  const [selectedOption, setSelectedOption] = useState("");
  const [formData, setFormData] = useState(initialState);

  const selectOptions = Object.keys(data);

  useEffect(() => {
    fetch("http://localhost:3001/")
      .then((r) => r.json())
      .then((r) => {
        setData(r);
      });
  }, []);

  const handleOptionChange = (event) => {
    setSelectedOption(event.target.value);
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!selectedOption) {
      setShowAlert(true);
      return;
    }

    const newChild = {
      answer: formData.answer,
    };

    const jsonData = { ...data };

    if (jsonData[selectedOption] && jsonData[selectedOption].children) {
      jsonData[selectedOption].children[formData.question] = newChild;
    } else {
      jsonData[selectedOption].children = {
        [formData.question]: newChild,
      };
    }
    console.log(jsonData);

    setData(jsonData);
    fetch("http://localhost:3001/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(jsonData),
    }).then(() => console.log("poslato", JSON.stringify(jsonData)));

    setFormData(initialState);
    setShowAlert(true);
  };

  useEffect(() => {
    if (showAlert) {
      setTimeout(() => {
        setShowAlert(false);
      }, 2000);
    }
  }, [showAlert]);

  // Inline style for the table
  const tableStyle = {
    borderCollapse: "collapse",
    border: "1px solid #ccc",
    width: "50%", // Adjust the width as needed
    marginLeft: "auto",
    marginRight: "auto",
  };

  // Inline style for table cells (td)
  const cellStyle = {
    border: "1px solid #ccc",
    padding: "8px",
  };

  const handleDelete = (question) => {
    const updatedData = { ...data };

    if (updatedData[selectedOption] && updatedData[selectedOption].children) {
      delete updatedData[selectedOption].children[question];
      // Update the state to reflect the change
      let newData = data;
      newData[selectedOption] = updatedData[selectedOption];
      setData(newData);
      fetch("http://localhost:3001/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newData),
      }).then(() => console.log("poslato", JSON.stringify(newData)));
    }

    setShowAlert(true);
  };

  // ...

  // Render the table based on jsonData
  const renderTable = () => {
    if (!selectedOption) {
      return null;
    }

    const selectedData = data[selectedOption];
    if (!selectedData || !selectedData.children) {
      return null;
    }

    const childData = selectedData.children;
    const rows = [];

    for (const question in childData) {
      const answer = childData[question].answer;

      rows.push(
        <tr key={question}>
          <td style={cellStyle}>{question}</td>
          <td style={cellStyle}>{answer}</td>
          <td style={cellStyle}>
            <button onClick={() => handleDelete(question)}>Obriši</button>
          </td>
        </tr>
      );
    }

    return (
      <div>
        <h3>sadržaj</h3>
        <table style={tableStyle}>
          <thead>
            <tr>
              <th style={cellStyle}>Pitanje</th>
              <th style={cellStyle}>Odgovor</th>
              <th style={cellStyle}>Akcija</th>
            </tr>
          </thead>
          <tbody>{rows}</tbody>
        </table>
      </div>
    );
  };

  return (
    <Wrapper className="full-page">
      <form className="form" onSubmit={handleSubmit}>
        <Logo />
        <h3>Dodaj sadržaj</h3>
        {showAlert && <Alert />}
        {/* name input */}
        <select
          className="form-select"
          value={selectedOption}
          onChange={handleOptionChange}
        >
          <option value="">Izaberi oblast</option>
          {selectOptions.map((option, index) => (
            <option key={index} value={option}>
              {option}
            </option>
          ))}
        </select>
        {/* Pitanje (Question) input */}
        <FormRow
          type="text"
          labelText={"Pitanje"}
          name="question"
          value={formData.question}
          handleChange={handleInputChange}
        />
        {/* Odgovor (Answer) input */}
        <FormRow
          type="textarea"
          labelText={"Odgovor"}
          name="answer"
          value={formData.answer}
          handleChange={handleInputChange}
        />
        <button type="submit" className="btn btn-block">
          Dodaj
        </button>
      </form>
      {renderTable()}
    </Wrapper>
  );
};

export default Form;
