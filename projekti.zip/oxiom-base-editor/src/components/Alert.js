const Alert = () => {
  return <div className={`alert alert-success`}>Sadržaj uspješno dodat!</div>;
};

export default Alert;
