let BASE = {};
let PATH = [];
let AI_MODE = false;

const START_MESSAGE =
  "Dobro došli u Oxiom bot. Izaberite oblast o preduzetnistvu koja Vas zanima.";

addMessageBot(START_MESSAGE);

function baseWithPath() {
  let r = BASE;
  PATH.forEach((el) => {
    r = r[el].children;
  });

  return r;
}

function addButtons() {
  document.querySelector(".chat-buttons-container").innerHTML = "";
  let container = document.createElement("div");
  container.classList.add("chat-buttons");
  document.querySelector(".chat-buttons-container").appendChild(container);

  if (baseWithPath() != undefined) {
    Object.keys(baseWithPath()).forEach(function (q) {
      const button = document.createElement("div");
      button.classList.add("button");
      button.innerHTML = q;
      document.querySelector(".chat-buttons").appendChild(button);
    });
  }

  document.querySelectorAll(".chat-buttons .button").forEach(function (butt) {
    butt.addEventListener("click", (e) => {
      addMessageUser(butt.innerHTML, "message-user");
    });
  });

  let button = document.createElement("div");
  button.classList.add("button", "button-back");
  button.innerHTML = "NAZAD";
  button.addEventListener("click", function (e) {
    addMessageUser("/nazad");
  });
  document.querySelector(".chat-buttons-container").appendChild(button);

  button = document.createElement("div");
  button.classList.add("button", "button-home");
  button.innerHTML = "POCETNA";
  button.addEventListener("click", function (e) {
    addMessageUser("/pocetna");
  });
  document.querySelector(".chat-buttons-container").appendChild(button);
}

function _addMessage(message, _class) {
  const chatMessages = document.querySelector(".chat-messages");
  const newMessage = document.createElement("div");
  newMessage.classList.add(_class);
  newMessage.innerHTML = message;
  chatMessages.appendChild(newMessage);

  const scrollContainer = document.querySelector(".chat-messages");
  scrollContainer.scrollTo(0, scrollContainer.scrollHeight);
}

function addMessageBot(message) {
  _addMessage(message, "message-bot");
}

function addMessageUser(message) {
  _addMessage(message, "message-user");

  if (message == "/nazad") {
    if (AI_MODE) {
      addMessageBot("---KRAJ AI MODA---");
      AI_MODE = false;
    }
    if (PATH.length == 0) {
      addMessageBot("Ne možete se vratiti nazad, na početnoj ste strani.");
    }
    PATH.pop();
    addButtons();
  } else if (message == "/pocetna") {
    if (PATH.length == 0) {
      addMessageBot("Već ste na početnoj strani.");
    }
    if (AI_MODE) {
      addMessageBot("---KRAJ AI MODA---");
      AI_MODE = false;
    }
    PATH = [];
    addButtons();
    addMessageBot(START_MESSAGE);
  } else if (
    !AI_MODE &&
    baseWithPath() != undefined &&
    baseWithPath()[message]
  ) {
    if (baseWithPath()[message].ai_mode) {
      AI_MODE = true;
    } else {
      addMessageBot(baseWithPath()[message].answer);
    }

    PATH.push(message);
    addButtons();
  } else if (AI_MODE) {
    document.querySelector(".typing-indicator").classList.remove("hidden");
    fetch("http://localhost:3000", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: `{"prompt": "${message}"}`,
    })
      .then(function (r) {
        return r.text();
      })
      .then(function (r) {
        addMessageBot(r);
        document.querySelector(".typing-indicator").classList.add("hidden");
      });
  }
}

fetch(/*"baza.json"*/ "http://localhost:3001/")
  .then((r) => r.json())
  .then((r) => {
    BASE = r;

    addButtons();
  });

document
  .querySelector(".chat-input")
  .addEventListener("keypress", function (e) {
    if (e.key === "Enter") {
      const message = this.value;
      addMessageUser(message, "message-user");
      this.value = "";
    }
  });

document.querySelector(".refresh").addEventListener("click", function (e) {
  addMessageUser("/pocetna");
  addMessageBot("REFRESH JE U TOKU...");

  fetch(/*"baza.json"*/ "http://localhost:3001/")
    .then((r) => r.json())
    .then((r) => {
      BASE = r;

      addButtons();
      addMessageBot("REFRESH GOTOV");
    });
});
